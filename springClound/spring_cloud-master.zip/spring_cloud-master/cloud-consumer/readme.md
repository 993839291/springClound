
com.hry.spring.cloud.consumer.simple
- 通过EurekaClient + feign + hystrix实现对服务端的调用
com.hry.spring.cloud.consumer.simple2
- 通过最原始的方式EurekaClient + ribbon + hystrix对服务的调用