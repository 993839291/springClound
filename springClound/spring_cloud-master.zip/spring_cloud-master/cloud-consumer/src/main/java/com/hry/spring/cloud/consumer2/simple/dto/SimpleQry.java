package com.hry.spring.cloud.consumer2.simple.dto;

public class SimpleQry {
	private Integer randomNum;
	private String transparentString;
	
	public Integer getRandomNum() {
		return randomNum;
	}
	public void setRandomNum(Integer randomNum) {
		this.randomNum = randomNum;
	}
	public String getTransparentString() {
		return transparentString;
	}
	public void setTransparentString(String transparentString) {
		this.transparentString = transparentString;
	}
}
